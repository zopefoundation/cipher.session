================
 repoze.session
================

An HTTP sessioning system for web applications, based on code from the
`<faster http://agendaless.com/Members/tseaver/software/faster/>`_
Zope 2 product.  ``repoze.session`` uses ZODB as its persistence
mechanism.

See the ``docs`` subdirectory or `http://docs.repoze.org/session/
<http://docs.repoze.org/session/>`_ for more documentation.

